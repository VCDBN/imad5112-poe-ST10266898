package com.example.testpoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

lateinit var numberList: ArrayList<Int>

var numbersEntered = 0
var sum = 0
var min = 0
var max = 0

lateinit var minMaxTextView: TextView
lateinit var averageTextView: TextView
lateinit var numbersTextView: TextView
lateinit var minMaxbutton: Button
lateinit var averagebutton: Button
lateinit var clearbutton: Button
lateinit var addButton: Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        numberList = ArrayList()


        addButton = findViewById(R.id.addButton)
        clearbutton = findViewById(R.id.clearButton)
        averagebutton = findViewById(R.id.averageButton)
        minMaxbutton = findViewById(R.id.minMaxButton)



        addButton.setOnClickListener {
            val numberEditText = findViewById<EditText>(R.id.numberEditText)
            val number = numberEditText.text.toString().toInt()

            numberList = ArrayList()
            var numbersEntered = 0



            if (numbersEntered < 10) {
                numberList.add(number)
                numbersEntered++

                val numbersTextView = findViewById<TextView>(R.id.numbersTextView)
                numbersTextView.text = "Numbers: ${numberList.joinToString()}"

                numberEditText.setText("")
            }









            clearbutton.setOnClickListener {
                numberList.clear()

                // numbersEntered = 0
                // Average = 0
                // Min Max = 0

                val numbersTextView = findViewById<TextView>(R.id.numbersTextView)
                numbersTextView.text = "Numbers: "

            }






            averagebutton.setOnClickListener {
                var sum = 0
                var number = 0

                /*  for (number in numberList) {
                      sum += number
                  }*/

                // Use a while loop to iterate through the array
                while (number < numbersEntered) {
                    sum+= numberList [number]
                    number++
                }


                val average = if (numbersEntered > 0) (sum.toDouble() / numbersEntered) else 0.0

                val averageTextView = findViewById<TextView>(R.id.averageTextView)
                averageTextView.text = "Average: $average"
            }

            minMaxbutton.setOnClickListener {
                var min = Int.MAX_VALUE
                var max = Int.MIN_VALUE



                for (number in numberList) {
                    if (number < min) {
                        min = number
                    }
                    if (number > max) {
                        max = number
                    }
                }

                val minMaxTextView = findViewById<TextView>(R.id.minMaxTextView)
                minMaxTextView.text = "Min: $min, Max: $max"
            }

        }
    }}